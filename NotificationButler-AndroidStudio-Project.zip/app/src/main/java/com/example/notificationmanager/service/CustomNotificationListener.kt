package com.example.notificationmanager.service

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CustomNotificationListener : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "Notification Butler connected to Android System Server!")
        interceptionCount = activeNotifications?.size ?: 0
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn ?: return

        // Prevent intercepting our own alerts
        if (sbn.packageName == packageName) return

        val extras: Bundle = sbn.notification.extras ?: Bundle()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "No Title"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "No Text"
        val fullContent = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: text

        Log.d(TAG, "INTERCEPTED [\${sbn.packageName}]: '$title' -> '$fullContent'")
        interceptionCount++

        serviceScope.launch {
            // DEMO RULE 1: Auto-cancel marketing promo spam
            if (fullContent.contains("50% OFF", ignoreCase = true) || fullContent.contains("promo code", ignoreCase = true)) {
                Log.w(TAG, "Spam detected! Dismissing notification with key: \${sbn.key}")
                cancelNotification(sbn.key)
                return@launch
            }

            // DEMO RULE 2: Auto-snooze Slack / Work during quiet hours (e.g. 15 minutes)
            if (sbn.packageName.contains("slack") && title.contains("urgent", ignoreCase = true).not()) {
                Log.i(TAG, "Snoozing Slack notification for 15 minutes")
                snoozeNotification(sbn.key, 15 * 60 * 1000L)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        sbn?.let {
            Log.d(TAG, "Notification removed: \${it.packageName}")
        }
    }

    companion object {
        private const val TAG = "NotificationButler"
        var interceptionCount: Int = 0
    }
}
