package com.example.notificationmanager.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.notificationmanager.R
import com.example.notificationmanager.notifications.NotificationChannelsManager
import com.example.notificationmanager.service.CustomNotificationListener
import com.example.notificationmanager.util.BatteryOptimizationHelper
import com.example.notificationmanager.util.PermissionHelper

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvCount: TextView
    private lateinit var btnEnableAccess: Button
    private lateinit var btnBattery: Button
    private lateinit var btnTestNotif: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Setup notification channel
        NotificationChannelsManager(this).setupChannels()

        // Check POST_NOTIFICATIONS for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        tvStatus = findViewById(R.id.tvPermissionStatus)
        tvCount = findViewById(R.id.tvCaptureCount)
        btnEnableAccess = findViewById(R.id.btnEnableAccess)
        btnBattery = findViewById(R.id.btnBatteryExemption)
        btnTestNotif = findViewById(R.id.btnSendTestNotification)

        btnEnableAccess.setOnClickListener {
            PermissionHelper.openNotificationAccessSettings(this)
            Toast.makeText(this, "Find 'Notification Butler' and toggle it ON", Toast.LENGTH_LONG).show()
        }

        btnBattery.setOnClickListener {
            BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(this)
        }

        btnTestNotif.setOnClickListener {
            sendLocalTestNotification()
        }
    }

    override fun onResume() {
        super.onResume()
        updateUiStatus()
    }

    private fun updateUiStatus() {
        val isGranted = PermissionHelper.isNotificationAccessGranted(this)
        if (isGranted) {
            tvStatus.text = "ACTIVE - Notification Listener Connected"
            tvStatus.setTextColor(android.graphics.Color.parseColor("#10B981"))
            btnEnableAccess.isEnabled = false
            btnEnableAccess.text = "Permission Granted ✓"
        } else {
            tvStatus.text = "INACTIVE - Permission Required"
            tvStatus.setTextColor(android.graphics.Color.parseColor("#EF4444"))
            btnEnableAccess.isEnabled = true
            btnEnableAccess.text = "Grant Notification Access in Settings"
        }

        tvCount.text = "Intercepted Events: \${CustomNotificationListener.interceptionCount}"
    }

    private fun sendLocalTestNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NotificationChannelsManager.CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pinaki Test Dispatch")
            .setContentText("50% OFF flash sale demo! Watch listener auto-cancel this spam.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        nm.notify(1001, notif)
        Toast.makeText(this, "Dispatched test alert. Watch Logcat!", Toast.LENGTH_SHORT).show()
    }
}
