package com.example.notificationmanager.service

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.StatusBarNotification
import android.util.Log

object DirectReplyHelper {
    private const val TAG = "DirectReplyHelper"

    fun sendReply(context: Context, sbn: StatusBarNotification, replyMessage: String): Boolean {
        val actions = sbn.notification.actions ?: return false

        for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            for (remoteInput in remoteInputs) {
                if (remoteInput.allowFreeFormInput || remoteInput.resultKey != null) {
                    try {
                        val intent = Intent()
                        val bundle = Bundle()
                        bundle.putCharSequence(remoteInput.resultKey, replyMessage)
                        RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)
                        action.actionIntent.send(context, 0, intent)
                        Log.i(TAG, "Sent synthetic reply to \${sbn.packageName}: '$replyMessage'")
                        return true
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to send direct reply", e)
                    }
                }
            }
        }
        return false
    }
}
