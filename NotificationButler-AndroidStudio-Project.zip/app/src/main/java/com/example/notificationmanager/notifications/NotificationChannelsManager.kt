package com.example.notificationmanager.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build

class NotificationChannelsManager(private val context: Context) {

    fun setupChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channel = NotificationChannel(
            CHANNEL_ALERTS,
            "Butler Status & Digests",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notification Butler alerts and digests"
            enableLights(true)
            lightColor = Color.GREEN
            enableVibration(true)
        }

        notificationManager.createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ALERTS = "channel_butler_alerts"
    }
}
