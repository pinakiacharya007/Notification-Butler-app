# Notification Butler Android Project
Built for Pinaki - Android Notification Manager (API 26-35)

## How to Install and Run on Your Android Device:

### Step 1: Open in Android Studio
1. Unzip this downloaded archive.
2. Open Android Studio (Koala, Ladybug, or newer).
3. Click **File > Open...** and select the unzipped directory.
4. Allow Gradle to sync.

### Step 2: Connect Your Android Phone
1. On your Android phone, open **Settings > About Phone**.
2. Tap **Build Number** 7 times to enable **Developer Options**.
3. Go to **Settings > System / Developer Options** and enable **USB Debugging** (or Wireless Debugging).
4. Connect phone via USB cable and allow the debugging prompt on your phone screen.

### Step 3: Run the App
1. In Android Studio, select your physical phone in the device dropdown.
2. Click the green **Run (Shift + F10)** button.
3. The app will install and open on your phone!

### Step 4: Grant Notification Access
1. In the app on your phone, tap **"Grant Notification Access in Settings"**.
2. Find **"Notification Butler"** in the list and toggle the switch **ON**.
3. Return to the app. The status will display **"ACTIVE"** in green!

### Step 5: Test It!
- Tap **"Dispatch Test Spam Notification"** or send yourself a WhatsApp / Slack message with "50% OFF".
- Check Android Studio's **Logcat** tab (filter by `NotificationButler`) to see real-time intercepted notifications, titles, bodies, and auto-dismiss actions in action!
